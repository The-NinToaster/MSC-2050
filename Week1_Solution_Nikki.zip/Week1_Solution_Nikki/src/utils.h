#pragma once

int myAdd(int a, int b) 
{
    return (a) + (b); 
}

int myMul(int a, int b)
{
    return (a) * (b); 
}

