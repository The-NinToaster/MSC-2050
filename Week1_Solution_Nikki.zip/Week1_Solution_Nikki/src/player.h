#pragma once
#include "utils.h"

int NUM_PLAYERS = 0; 

int addPlayer()
{
    NUM_PLAYERS = myAdd(NUM_PLAYERS, 1);   
}