#include <stdio.h>
#include "player.h"
#include "utils.h"


int main(int argc, char** argv) 
{

    printf("Running Week 1 script....\n");

    int result_one = myAdd(2,2); 
    printf("Result of myAdd with parametres 2,2 is: %d\n", result_one);

    int result_two = myMul(3,3); 
    printf("Result of myMul with parametres 3,3 is: %d\n", result_two);

    for (int a = 0; a < 5; a++)
       {    
           addPlayer();
        }
    
   while(NUM_PLAYERS < 20)
       { 
           addPlayer();
        }


    printf("The final value of variable NUM_PLAYERS is: %d\n", NUM_PLAYERS); 
}